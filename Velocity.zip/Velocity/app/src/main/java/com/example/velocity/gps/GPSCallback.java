package com.example.velocity.gps;

import android.location.Location;

public interface GPSCallback
{
    void onGPSUpdate(Location location);
}
